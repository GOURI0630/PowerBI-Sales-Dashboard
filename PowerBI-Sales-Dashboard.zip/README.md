# 📈 Power BI Sales Dashboard

An interactive Power BI dashboard to analyze sales performance across regions, products, and customer segments.

## 📌 Features
- Total Revenue, Profit, and Quantity KPIs
- Monthly and Yearly sales trends
- Top-performing products & regions
- Customer segmentation analysis
- Dynamic filters for region & category

## 📂 Dataset
The dataset contains:
- Date
- Region
- Product
- Category
- Quantity
- Sales
- Profit

## 🚀 How to Use
1. Open `sales_data.csv` in Power BI Desktop.
2. Create visuals like bar charts, line charts, and KPI cards.
3. Add slicers for `Region` and `Category`.
4. Save your work as `PowerBI_Sales_Dashboard.pbix`.
5. Upload it to GitHub along with this dataset and README.

⭐ **Made with ❤️ by [Gouri Sunil Kumar](https://github.com/GOURI0630)**
